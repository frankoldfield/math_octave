% Funcion para calcular los coeficientes del polinomio interpolador dado en
% la forma de Newton en formato a_nx^n+a_(n-1)x^(n-1)+...+a_1x+a_0
% Entrada:   
%            - coefNewton = coeficientes del polinomio interpolador en la
%            forma de Newton del polinomio 
%
%            - x = vector que contiene las abscisas de los n+1 puntos a interpolar (nodos)
%
%            - y= valores de la funcion en los n+1 nodos de interpolacion
% Salida: 
%            -  = tabla de las diferencias divididas
% El numero de nodos de interpolacion (n+1), lo obtiene a partir de la longitud de x.

function  p = poly_interpolador(x,coefNewton)
  n=length(coefNewton)-1;
  p=zeros(1,n+1);
  for i=n+1:-1:1
    for k=n+2-i:-1:2
      p(k)=p(k-1)-p(k)*x(i);
    end
    p(1)=coefNewton(i)-p(1)*x(i);
  end
  p;
  p=flip(p);
 

end
