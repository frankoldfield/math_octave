
function nodosTch = nodosTchevichev (a,b,n)
  nodosTch=zeros(1,n+1);
  for k=0:n
    nodosTch(k+1)= a+ (b-a)* (1 + cos((2*k+1)*pi/(2*(n+1))))/2;
  endfor
endfunction
