%funcion que da las dos raices de
% polinomio a x^2+b x+ c

function  [x1,x2]=solve_2grado(a,b,c)
  
  raiz=sqrt(b*b-4*a*c);
  numerador1=-b+raiz;
  numerador2=-b-raiz;
  if(abs(numerador1)>abs(numerador2))
    x1=numerador1/(2*a);
    x2=c/(a*x1);
  else
    x1=numerador2/(2*a);
    x2=c/(a*x1);
  endif
endfunction
