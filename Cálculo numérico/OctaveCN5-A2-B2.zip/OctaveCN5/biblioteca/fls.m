

% Funcion para redondear un numero real  x con d dígitos 
% en la mantisa que vienen dados por una variable global

function retval = fls(x)
  
  global ndigitos;
  % ndigitos contiene el número d
  retval=eval(mat2str(x,ndigitos));

endfunction
