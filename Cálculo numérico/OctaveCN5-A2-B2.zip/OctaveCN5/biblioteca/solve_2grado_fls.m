%funcion que da las dos raices de
% polinomio a x^2+b x+ c

function  [x1,x2]=solve_2grado_fls(a,b,c)
  b=fls(b);
  a=fls(a);
  c=fls(c);
  raiz=fls(sqrt(fls(b*b)-fls(4*fls(a*c))));
  numerador1=fls(-b+raiz);
  numerador2=fls(-b-raiz);
  if(abs(numerador1)>abs(numerador2))
    x1=fls(numerador1/fls(2*a));
    x2=fls(c/fls(a*x1));
  else
    x1=fls(numerador2/fls(2*a));
    x2=fls(c/fls(a*x1));
  endif
endfunction
