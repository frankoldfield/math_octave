function p_t = polyeval_newton(coefNewton, x_abcisas, t)
  n=length(coefNewton)-1;
  m=length(t);
  p_t=coefNewton(n+1)*ones(1,m);
  dif=zeros(n,m);
  for i=1:n
    dif(i,:)=(t.-x_abcisas(i));
  end
  for i=n:-1:1
    p_t=p_t.*dif(i,:).+coefNewton(i);
  end
end