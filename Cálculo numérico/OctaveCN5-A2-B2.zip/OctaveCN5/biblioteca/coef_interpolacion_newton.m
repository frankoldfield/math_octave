function coefNewton = coef_interpolacion_newton(x, y)
% Funcion para calcular los coeficientes del polinomio interpolador en la
% forma de Newton.
% Entrada:   
%            - x = vector que contiene los n+1 nodos de interpolacion
%            - y = valores de la funcion en los n+1 nodos de interpolacion
% Salida:    
%            - coefNewton = coeficientes del polinomio interpolador de
%      
  n=length(x)-1;
  if length(y) ~= n+1
    error('las dimensiones de x e y no coinciden');
  end
  coefNewton=y;
  for i=1:n
    for j=n:-1:i
      coefNewton(j+1)=(coefNewton(j+1)-coefNewton(j))/(x(j+1)-x(j+1-i));
    end
  end
end
