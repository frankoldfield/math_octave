% Ejercicio

clear all
clc


disp('Ejercicio 2')
addpath('../biblioteca')

x=[0.3,0.37,0.41,0.52]
y=[0.97741,0.96557,0.95766,0.93157]

difdiv=diferencias_divididas(x,y);

coefNewton = coef_interpolacion_newton(x, y)

pol=polinomio_interpolador(difdiv,x);

xn=0.47

%yn=eval(pol,x=xn)
%x=[0.3,0.37,0.41,0.52]
 p = poly_interpolador(x,coefNewton)
polyout(p,'x')
yn=polyval(p,xn)

yn=polyeval_newton(coefNewton, x, xn)

yreal= 0.94423;
error= abs(yreal-yn)

xamp=[x,xn]
yamp=[y,yreal]
difdiv2=diferencias_divididas(xamp,yamp);

coefNewton2 = coef_interpolacion_newton(xamp,yamp)

pol2=polinomio_interpolador(difdiv2,xamp);

%xn=0.47

%yn=eval(pol,x=xn)
%x=[0.3,0.37,0.41,0.52]
 p4 = poly_interpolador(xamp,coefNewton2)
polyout(p4,'x')

listax=linspace(0.2,0.7,67);
plot(xamp,yamp,'r*',listax,polyval(p,listax),listax,polyval(p4,listax))


rmpath('../biblioteca')