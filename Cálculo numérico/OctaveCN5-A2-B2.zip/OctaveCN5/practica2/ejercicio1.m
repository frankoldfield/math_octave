% Ejercicio

clear all
clc


disp('Ejercicio 1')
addpath('../biblioteca')
h=0.001;
derA=@(f,x) (f(x+h)-f(x-h))./(2*h);
condicion=@(f,x) abs(x.*derA(f,x)./f(x));

x=sqrt(2)
xapr=1.4

errx=abs((x-xapr)/x)

f1=@(x) (x-1)^6;
erry1=abs((f1(x)-f1(xapr))/f1(x))
ratio1=erry1/errx
cond1=condicion(f1,x)

f2=@(x) 1./(x+1)^6;
erry2=abs((f2(x)-f2(xapr))/f2(x))
ratio2=erry2/errx
cond2=condicion(f2,x)

f3=@(x) (3-2*x)^3;
erry3=abs((f3(x)-f3(xapr))/f3(x))
ratio3=erry3/errx
cond3=condicion(f3,x)

f4=@(x) 1./(3+2*x)^3;
erry4=abs((f4(x)-f4(xapr))/f4(x))
ratio4=erry4/errx
cond4=condicion(f4,x)

f5=@(x) 99-70*x;
erry3=abs((f3(x)-f3(xapr))/f3(x))
ratio5=erry3/errx
cond5=condicion(f5,x)

f6=@(x) 1./(99+70*x);
erry6=abs((f6(x)-f6(xapr))/f6(x))
ratio6=erry6/errx
cond6=condicion(f6,x)






rmpath('../biblioteca')