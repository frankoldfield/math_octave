%Ejercicio 1
clear all
clc

addpath('../biblioteca')

%datos
T=[0,0,3,3,5,5,9,9,12,12]
D=[0,0,99,99,165,165,290,290,380,380]
difdiv_2=[30,(D(3)-D(2))/(T(3)-T(2)),33,(D(5)-D(4))/(T(5)-T(4)),30,(D(7)-D(6))/(T(7)-T(6)),25,(D(9)-D(8))/(T(9)-T(8)),33]


difdiv=diferencias_divididas_Hermite(T,D,difdiv_2)
p9=coef_polinomio_interpolador(difdiv, T)

polyout(p9,'T')

% D en t=10
D_10=polyval(p9,10)

dp9=polyder(p9)

V_10=polyval(dp9,10)

% formula del error necesitamos estimacion de la derivada de orden 10 de f que no conocemos
% mirando en la �ltima columna de la tabla (f^10 / 10!) es del orden de 0.00005
estimacionDelError= 0.00005;
for i=1:10
  estimacionDelError =estimacionDelError * (10-T(i));
endfor
estimacionDelError
% mejor si tomamos polimos interpoladores de menor grado en puntos m�s proximos a 10

T4=[9,9,12,12]
D4=[290,290,380,380]
difdiv4=[25,(D(9)-D(8))/(T(9)-T(8)),33]
difdiv2=diferencias_divididas_Hermite(T4,D4,difdiv4)
p3=coef_polinomio_interpolador(difdiv2, T4)

nD_10=polyval(p3,10)
dpr=polyder(p3)
nV_10=polyval(dpr,10)
% formula del error necesitamos estimacion de la derivada de orden 10 de f que no conocemos
% mirando en la �ltima columna de la tabla (f^4 / 4!) es del orden de 0.17 (quinta columna de dd)
estimacionDelError2= 0.17 ;
for i=1:4
  estimacionDelError2 =estimacionDelError2 * (10-T4(i));
endfor
estimacionDelError2

rmpath('../biblioteca')