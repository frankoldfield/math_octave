%%% Ejercicio 4
clear all
clc
clf

addpath('../biblioteca')

%   Se quiere aproximar la parte superior del dibujo de un pato en vuelo y se tienen los
%   siguientes puntos por los que debe pasar la curva
x = [0.9, 1.3, 1.9, 2.1, 2.6, 3.0, 3.9, 4.4, 4.7, 5.0, 6.0, 7.0, 8.0, 9.2, 10.5, 11.3, 11.6, 12.0, 12.6, 13.0, 13.3];
%   e y=f(x)
y = [1.3, 1.5, 1.85, 2.1, 2.6, 2.7, 2.4, 2.15, 2.05, 2.1, 2.25, 2.3, 2.25, 1.95, 1.4, 0.9, 0.7, 0.6, 0.5, 0.4, 0.25];


%%(i) Utiliza interpolaci�n polinomial de Lagrange para aproximar la curva. Dibuja la gr�fica.

coefNewton = coef_interpolacion_newton(x,y);
polinomioLagrange= poly_interpolador(x,coefNewton);

figure(1)
v_x=linspace(0.9,13.3,127);
plot(x,y,'o-;poligonal puntos;',v_x,polyval(polinomioLagrange,v_x),'b;Lagrange;')
title('y=p(x), polinomio interpolador de Lagrange')


%%ii) Utiliza splines c�bicos naturales para aproximar la curva. Dibuja la gr�fica.

[b,c,d]=splineNatural(x,y);
figure(2)
v_x=linspace(0.9,13.3,127);
plot(x,y,'o-;poligonal puntos;',v_x,splineEval(x,y,b,c,d,v_x),'r;Spline;')
ylim([-1,6]);
title('y=p_i(x), Spline natural')



rmpath('../biblioteca')