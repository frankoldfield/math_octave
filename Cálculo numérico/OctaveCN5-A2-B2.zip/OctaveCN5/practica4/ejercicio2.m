%ejercicio 2 Runge nodos equidistribuidos
clear all
clc
clf

addpath('../biblioteca')

display('Efecto de Runge')

f=@(x) 1 ./ (1+ x.^2)
a=-5;
b=+5;

display('a) polinomios interpoladores y splines')

n=[1,4,14,19];
np=n+1

figure(1)
v_x=linspace(a,b,127);

plot(v_x,f(v_x),'k;f(x);')
ylim([-0.5,1.5])
grid on
hold on

%  con p=cell(1, length(n))    p{1} el primer polinomio
##
p=cell(1,length(n))

for k=1:length(n)
##
absc=nodosTchevichev(a,b,n(k));
orden=f(absc);
##
coefNewton = coef_interpolacion_newton(absc,orden);
p {k} = poly_interpolador(absc,coefNewton);
##% polyout(p,'x')
  switch(k)
    case 1
      etn=['r*;nodos', mat2str(n(k)), ';'];
      etp=['r;P', mat2str(n(k)), ';'];
   case 2
      etn=['g*;nodos', mat2str(n(k)), ';'];
      etp=['g;P', mat2str(n(k)), ';'];
    case 3
      etn=['b*;nodos', mat2str(n(k)), ';'];
      etp=['b;P', mat2str(n(k)), ';'];
    otherwise
     etn=['k*;nodos', mat2str(n(k)), ';'];
      etp=['k;P', mat2str(n(k)), ';'];
  endswitch
plot(absc,orden,etn,v_x,polyval(p{k},v_x),etp)

##
end


legend("location","northeast")
title('polinomios de Tchevichev')
hold off

figure(2)
%v_x=linspace(a,b,127);

plot(v_x,f(v_x),'k;f(x);')
ylim([-0.5,1.5])
grid on
hold on

%  con a,...,d=cell(1, length(n))   guardamos a_i,b_i...
##
as=cell(1,length(n))
bs=cell(1,length(n))
c=cell(1,length(n))
d=cell(1,length(n))
x=cell(1,length(n))

for k=1:length(n)
##
x{k}=linspace(a,b,np(k));
as{k}= f(x{k});
##
[bs{k},c{k},d{k}] = splineNatural(x{k},as{k});

##% polyout(p,'x')
  switch(k)
    case 1
      etn=['r*;nodos', mat2str(n(k)), ';'];
      etp=['r;S', mat2str(n(k)), ';'];
   case 2
      etn=['g*;nodos', mat2str(n(k)), ';'];
      etp=['g;S', mat2str(n(k)), ';'];
    case 3
      etn=['b*;nodos', mat2str(n(k)), ';'];
      etp=['b;S', mat2str(n(k)), ';'];
    otherwise
     etn=['k*;nodos', mat2str(n(k)), ';'];
      etp=['k;S', mat2str(n(k)), ';'];
  endswitch
plot(x{k},as{k},etn,v_x, splineEval(x{k},as{k},bs{k},c{k},d{k},v_x) ,etp)

##
end


legend("location","northwest")
title('ajuste Splines Naturales')
hold off


figure(3)  %splines sujetos
%v_x=linspace(a,b,127);

plot(v_x,f(v_x),'k;f(x);')
ylim([-0.5,1.5])
grid on
hold on

%  con a,...,d=cell(1, length(n))   guardamos a_i,b_i...
##
%as=cell(1,length(n))
Sbs=cell(1,length(n))
Sc=cell(1,length(n))
Sd=cell(1,length(n))
%x=cell(1,length(n))

tan_ini=0  %% 0 ,+1,-1,+100,-100
tan_fin=0

for k=1:length(n)
##
%x{k}=linspace(a,b,np(k));
%as{k}= f(x{k});
##
[Sbs{k},Sc{k},Sd{k}] = splineSujeto(x{k},as{k},tan_ini,tan_fin);

##% polyout(p,'x')
  switch(k)
    case 1
      etn=['r*;nodos', mat2str(n(k)), ';'];
      etp=['r;S', mat2str(n(k)), ';'];
   case 2
      etn=['g*;nodos', mat2str(n(k)), ';'];
      etp=['g;S', mat2str(n(k)), ';'];
    case 3
      etn=['b*;nodos', mat2str(n(k)), ';'];
      etp=['b;S', mat2str(n(k)), ';'];
    otherwise
     etn=['k*;nodos', mat2str(n(k)), ';'];
      etp=['k;S', mat2str(n(k)), ';'];
  endswitch
plot(x{k},as{k},etn,v_x, splineEval(x{k},as{k},Sbs{k},Sc{k},Sd{k},v_x) ,etp)

##
end


legend("location","northwest")
title('ajuste Splines Sujetos')
hold off

figure(4) %errores
%np lista con los n�meros de puntos

k=4
%v_x abscisas para las gr�ficas
errSplNat=abs(f(v_x)-splineEval(x{k},as{k},bs{k},c{k},d{k},v_x));
errSplSuj=abs(f(v_x)-splineEval(x{k},as{k},Sbs{k},Sc{k},Sd{k},v_x));

plot(x{k},zeros(1,np(k)),'o',v_x,errSplNat,'b;Error Sp Nat;',v_x,errSplSuj,'r;Error Sp Suj;')




rmpath('../biblioteca')