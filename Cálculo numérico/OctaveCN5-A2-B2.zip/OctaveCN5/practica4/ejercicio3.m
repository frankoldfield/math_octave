%ejercicio 3
clear all
clc
clf

addpath('../biblioteca')

X=[0,1,4,5,7,7,8,9]
Y=[0,-1,5,3,5,0,-1,0]

XY=[X;Y]
Puntos=transpose(XY)

plot(X,Y,'o')
xlim([-2,11])
ylim([-5,10])
h=0.1;
for k=1:length(X)
text(X(k)+h,Y(k)+h,mat2str(k))  
end

T=1:length(X)
[bx,cx,dx]=splineNatural(T,X);
[by,cy,dy]=splineNatural(T,Y);

v_t=linspace(1,length(X),127);

%plot(splineX,spxlineY) En la sesi�n llegamos hasta aqu�. Para termnar:

hold on
plot(splineEval(T,X,bx,cx,dx,v_t),splineEval(T,Y,by,cy,dy,v_t),'b;con Splines Nat;')

%(ii) Splines c�bicos sujetos con x?(0) =y?(0) = 1 y x?(7) =y?(7) = 1

[bxS,cxS,dxS]=splineSujeto(T,X,1,1);
[byS,cyS,dyS]=splineSujeto(T,Y,1,1);
plot(splineEval(T,X,bxS,cxS,dxS,v_t),splineEval(T,Y,byS,cyS,dyS,v_t),'r;con Splines Suj;')

hold off
rmpath('../biblioteca')