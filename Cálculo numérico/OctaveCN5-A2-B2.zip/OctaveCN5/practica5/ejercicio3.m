%ejercicio 3

clear all

clc

disp('Ejercicio 1')

addpath('../biblioteca')
format long g

n=[10,100,1000];

f5=@(x) (sin(x)+ (x == 0) )./(x +(x==0)) 
a5=-1
b5=1
format long g
for k=1:3
  k
  simpf= simpson(f5,a5,b5,n(k))
  trapf=trapecios(f5,a5,b5,n(k))
end
valorOctaveMatlab=quad(f5,a5,b5)

aproxG3=gaussLegendre3(f5,a5,b5)


aproxG4=gaussLegendre4Compuesto(f5,a5,b5,10)

%%   Gauss Chevichev
f1=@(x) exp(x)./sqrt(1-x.*x)
f1_sinpeso=@(x) exp(x)

valorOctaveMaximaf1=quad(f1,-1,1)
display('Comentad las aproximaciones en funci�n de n !!!! ')
aproxGaussChev3=gaussChevichev(f1_sinpeso,3)
aproxGaussChev5=gaussChevichev(f1_sinpeso,5)
aproxGaussChev10=gaussChevichev(f1_sinpeso,10)
aproxGaussChev100=gaussChevichev(f1_sinpeso,100)


rmpath('../biblioteca')