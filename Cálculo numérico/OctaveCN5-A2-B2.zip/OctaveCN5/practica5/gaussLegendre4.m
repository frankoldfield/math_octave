

function intaprox = gaussLegendre4(f, a, b)
  alpha=sqrt( 3/7+ 2/7*sqrt(6/5));
  beta=sqrt( 3/7- 2/7*sqrt(6/5));
  puntos= a+ (b-a)/2*([-alpha,-beta,beta,alpha]+1);
  w1=(18-sqrt(30))/36;
  w2=(18+sqrt(30))/36;
  w=[w1,w2,w2,w1];
  intaprox=(b-a)/2*sum(w.*f(puntos));

endfunction
