%Ejercicio 1

clear all

clc

disp('Ejercicio 1')

addpath('../biblioteca')


f1=@(x) exp(x)./sqrt(1-x.*x)
a1=-1
b1=1

n=[10,100,1000]

simpf1= simpson(f1,a1,b1,n(3))
trapf1= trapecios(f1,a1,b1,n(3))

valorOctaveMaximaf1=quad(f1,a1,b1)

disp('la integral de f1 es impropia, hace falta otro m�todo')

f2=@(x) 1./ (1+ x.^2)
a2=0
b2=2
format long g
for k=1:3
  k
  simpf= simpson(f2,a2,b2,n(k))
  trapf2=trapecios(f2,a2,b2,n(k))
end
valorealIntf2=atan(2)

f3=@(x) x.^2 .* sin(x)
a3=0
b3=pi/4
format long g
for k=1:3
  k
  simpf= simpson(f3,a3,b3,n(k))
  trapf=trapecios(f3,a3,b3,n(k))
end
valorOctaveMatlab=integral(f3,a3,b3)

f5=@(x) (sin(x)+ (x == 0) )./(x +(x==0)) 
a5=-1
b5=1
format long g
for k=1:3
  k
  simpf= simpson(f5,a5,b5,n(k))
  trapf=trapecios(f5,a5,b5,n(k))
end
valorOctaveMatlab=quad(f5,a5,b5)



rmpath('../biblioteca')