%ejercicio 2
clear all
clc

disp('Ejercicio 2')

addpath('../biblioteca')

f=@(x) exp(-x.^2/2)

disp('apartado a)')

a=0
b=1

prec=1e-6

N=2
SN=simpson(f,a,b,N);
N=2*N;
S2N=simpson(f,a,b,N);
while 1/10*abs(S2N-SN) > prec
  SN=S2N;
  N=2*N;
  S2N=simpson(f,a,b,N);
end  
disp(' numero final de divisiones ')
N
disp('el valor aproximado de la integral es')
S2N

intOctaveMatlab=integral(f,a,b)

disp('apartado b')
% integrales de(f, -infinito,x)/ sqrt(2*pi) para los valores de x
% comprendidos entre 0 y 3.4 con incrementos de 0.01 
 
x=0:0.01:3.4;
longitud=length(x);

Nlista=zeros(1,longitud);

for k=1:longitud
  N=2;
  SN=simpson(f,0,x(k),N);
  N=2*N;
  S2N=simpson(f,0,x(k),N);
  while 1/10*abs(S2N-SN) > prec
    SN=S2N;
    N=2*N;
    S2N=simpson(f,0,x(k),N);
  end 
  Nlista(k)=0.5+1/sqrt(2*pi)*S2N; 
end  
format short g

%distribuir 340 numeros en tabla con 10 columnas
columnas=10
filas=floor(longitud/10)
Ntabla=zeros(filas,columnas);
for fila=1:filas
  for columna=1:columnas
    k=10*(fila-1)+columna;
    Ntabla(fila,columna)=Nlista(k);    
  end
end  





rmpath('../biblioteca')