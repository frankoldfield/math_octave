

function intaprox = gaussLegendre3 (f, a, b)
  
  puntos= a+ (b-a)/2*([-sqrt(3/5),0,sqrt(3/5)]+1)
  w=[5/9,8/9,5/9];
  intaprox=(b-a)/2*sum(w.*f(puntos));

endfunction
