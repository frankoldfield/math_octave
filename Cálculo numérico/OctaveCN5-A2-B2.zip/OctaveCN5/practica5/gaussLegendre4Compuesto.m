

function intaprox = gaussLegendre4Compuesto(f, A, B,N)
  x=linspace(A,B,N+1);
  
  alpha=sqrt( 3/7+ 2/7*sqrt(6/5));
  beta=sqrt( 3/7- 2/7*sqrt(6/5));
 
  w1=(18-sqrt(30))/36;
  w2=(18+sqrt(30))/36;
  w=[w1,w2,w2,w1];
  intaprox=0;
for k=1:N
   puntos= x(k)+ (x(k+1)-x(k))/2*([-alpha,-beta,beta,alpha]+1);
  intaprox=intaprox+(x(k+1)-x(k))/2*sum(w.*f(puntos));
end
endfunction
