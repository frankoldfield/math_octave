
%%Funcion para aproximar integrales impropias con la formula de cuadratura
%%de peso w(x)= 1/sqrt(1-x^2), denominada: cuadratura de Gauss Chevichev 
%%
%%Integral_{-1}^{+1}  f(x) / sqrt(1-x^2) dx = Suma_{i=1}^n  w_i f(x_i)
%%
%%los argumentos de la funci�n son:
%% -- la funci�n f(x)  (sin el peso w(x)= 1/sqrt(1-x^2))
%% -- el n�mero de puntos n a considerar.
 

function intaprox = gaussChevichev(f,n)
  
  I=1:n;
  puntos=cos((2*I -1)/(2*n) * pi);
  w= pi/n; 
  % otra alternativa m�s compleja manejando vectores y el producto .*
  % es poner:
  % w= pi/n*ones(1,n);
  intaprox=sum(w*f(puntos));
  % en la alternativa habria que poner
  % intaprox=sum(w.*f(puntos));

endfunction
