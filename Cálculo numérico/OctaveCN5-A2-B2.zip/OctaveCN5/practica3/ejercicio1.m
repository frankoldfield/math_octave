% ejercicio 1

clear all
clc

%clf(1)

v=[1:5:82]

v=1:5:82

w=[100:-10:-1]

a=-3
b=3

npuntos=13

u=linspace(a,b,npuntos)
u(4)
u=[1,7,-2]

u=zeros(1,3)


V_x=[0,1,2]; %abscisas
V_y=[0,2,0]; %ordenadas

figure(1)
plot(V_x,V_y)  %poligonal que une los puntos (0,0) (1,1) (2,0)
hold on

plot([0.5,1.5],[1,0],'*')


f=@(x) 2*x./(1.+x.^2);  %recordad operaciones punto a punto .* ./ .^ 
V_x=linspace(0,2,127);

figure(2)
plot(V_x,f(V_x))  %dibuja la grafica de f en [0,2] usando una poligonal de 127 puntos
xlim([-1,3])
ylim([-0.5,2])
title('Grafica de funcion')
grid on

figure(3)
x = 0:pi/10:2*pi;
y1 = sin(x);
y2 = sin(x-0.25);
y3 = sin(x-0.5);


%plot(x,y1,'g;sen(x);',x,y2,'b--o;sen(x-0.25);',x,y3,'r*;puntos;')
plot(x,y1,'g',x,y2,'b--o',x,y3,'r*')
legend('sen(x)','sen(x-0.25)','puntos')

figure(4)


f=@(x) (sin(x)+(x==0))./(x+(x==0) );
a=-3*pi;
b=3*pi;
nabs=127;
xabs=linspace(a,b,nabs);
plot(xabs,f(xabs),'b;sen(x)/x;',[a,b],[0,0])
ylim([-2,3])
grid on





