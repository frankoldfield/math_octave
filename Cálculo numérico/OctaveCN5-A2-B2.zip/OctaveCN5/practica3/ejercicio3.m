%ejercicio 2 Runge nodos equidistribuidos
clear all
clc
clf

addpath('../biblioteca')

display('Efecto de Runge')

f=@(x) 1 ./ (1+ x.^2);
a=-5;
b=+5;

display('a) polinomios interpoladores')

n=[5,15,20, 30];
np=n+1;

figure(1)
v_x=linspace(a,b,127);

plot(v_x,f(v_x),'k;f(x);')
ylim([-2,5])
grid on
hold on

%  con p=cell(1, length(n))    p{1} el primer polinomio

p=cell(1,length(n))

for k=1:length(n)

absc=nodosTchevichev(a,b,n(k));
orden=f(absc);

coefNewton = coef_interpolacion_newton(absc,orden);
p {k} = poly_interpolador(absc,coefNewton);
% polyout(p,'x')
  switch(k)
    case 1
      etn=['r*;nodos', mat2str(n(k)), ';'];
      etp=['r;P', mat2str(n(k)), ';'];
    case 2
      etn=['g*;nodos', mat2str(n(k)), ';'];
      etp=['g;P', mat2str(n(k)), ';'];
    case 3
      etn=['b*;nodos', mat2str(n(k)), ';'];
      etp=['b;P', mat2str(n(k)), ';'];
    otherwise
      etn=['k*;nodos', mat2str(n(k)), ';'];
      etp=['k;P', mat2str(n(k)), ';'];
  endswitch
plot(absc,orden,etn,v_x,polyval(p{k},v_x),etp)


end


legend("location","north")
hold off
display('b) y c) ')
m_x=linspace(a,b,101);

fprintf('\n n \t  log(||f-p{k}||)/n \t  x_max \n')
for k=1:length(n)
  
  [maximo,pos_maximo]=max(abs(f(m_x)-polyval(p{k},m_x)));
  fprintf('\n %d \t  %d \t %d \n',n(k),log(maximo)/n(k),m_x(pos_maximo))
  

endfor

figure(2)
hold on
for k=1:length(n)
  absc=nodosTchevichev(a,b,n(k));
  PI=poly(absc);
  switch(k)
    case 1
      etn=['r*;nodos', mat2str(n(k)), ';'];
      etp=['r;P', mat2str(n(k)), ';'];
    case 2
      etn=['g*;nodos', mat2str(n(k)), ';'];
      etp=['g;P', mat2str(n(k)), ';'];
    case 3
      etn=['b*;nodos', mat2str(n(k)), ';'];
      etp=['b;P', mat2str(n(k)), ';'];
    otherwise
      etn=['k*;nodos', mat2str(n(k)), ';'];
      etp=['k;P', mat2str(n(k)), ';'];
  endswitch
  plot(absc,zeros(1,np(k)),etn,v_x,log(1+abs(polyval(PI,v_x)))/n(k),etp) 
  
  
endfor
legend("location","north")
hold off

rmpath('../biblioteca')