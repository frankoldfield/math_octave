% Ejercicio

clear all
clc


disp('Ejercicio 5')
addpath('../biblioteca')

format long g

%aproximar la derivada de sen(x) en x=1
der=cos(1)

h=1E-4

fprintf(' i \t errAb \t errRel \n')
fprintf('---------------------------------------- \n')
for(i=5:16)
   h=h/10;
   deraprox=(sin(1+h)-sin(1))/h;
   errAb=abs(der-deraprox);
   errRel=errAb/der;
   fprintf(' %d \t %d \t %d \n',i,errAb,errRel)
endfor

global ndigitos;
ndigitos=8 
h=1E-3
i=3
fprintf('----con redondeo-------------------------------- \n')
deraprox=fls(fls(fls(sin(1+h))-fls(sin(1)))/h);
   errAb=abs(der-deraprox);
   errRel=errAb/der;
   fprintf(' %d \t %d \t %d \n',i,errAb,errRel)
   
%  Ver como es el error relativo en relacion con el tamaño de h   
%  Con una gráfica

eR= @(h) abs((sin(1+h)-sin(1))./h-cos(1)) ./ cos(1);
eR2= @(h) abs((sin(1+h)-sin(1-h))./(2*h)-cos(1)) ./ cos(1);

listah=linspace(0,0.1,37);

plot(listah,eR2(listah));







rmpath('../biblioteca')
