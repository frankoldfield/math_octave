% Ejercicio
disp('Ejercicio 2')
clear all
clc

addpath('../biblioteca')

global ndigitos=7;

a = 0.5234563
b = 0.5711321
c = -0.5988678 

primera_suma=fls(b+c)
suma_izda=fls(a+primera_suma)

segunda_suma=fls(a+b)
sumba_drcha=fls(segunda_suma+c)

