% Ejercicio

clear all
clc


disp('Ejercicio 4')

addpath('../biblioteca')
format long g
global ndigitos;
ndigitos=8;
nterm=1E3

% sum 1/k^2  desde k=1 hasta nterm (suma de terminos decrecientes
% sum 1/k^2  desde k=nterm hasta 1 (suma de terminos crecientes
sumaDfls=0;
sumaD=0;
tic
for(k=1:nterm)
  sumaDfls=fls(sumaDfls+fls(1/k^2));
  sumaD=sumaD+1/k^2;
endfor
toc
sumaDfls
sumaD


sumaCfls=0;
sumaC=0;
tic
for(k=nterm:-1:1)
  sumaCfls=fls(sumaCfls+fls(1/k^2));
  sumaC=sumaC+1/k^2;
endfor
toc
sumaCfls
sumaC

sumaSerie=pi^2/6

%% serie armonica divergente
nterm=1E4
sumaDfls=0;
sumaD=0;
tic
for(k=1:nterm)
  sumaDfls=fls(sumaDfls+fls(1/k));
  sumaD=sumaD+1/k;
endfor
toc
sumaDfls
sumaD


sumaCfls=0;
sumaC=0;
tic
for(k=nterm:-1:1)
  sumaCfls=fls(sumaCfls+fls(1/k));
  sumaC=sumaC+1/k;
endfor
toc
sumaCfls
sumaC
disp('suma infinito')

rmpath('../biblioteca')