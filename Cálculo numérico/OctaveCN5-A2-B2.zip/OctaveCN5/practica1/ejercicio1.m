% Ejercicio 1

disp('Ejercicio 1')
clear all
clc

global ndigitos=3;

Pi=pi
redondeado_de_pi= fls(pi)

ndigitos=7
redondeado_de_pi= fls(pi)