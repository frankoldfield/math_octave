% Ejercicio

clear all
clc


disp('Ejercicio 3')

addpath('../biblioteca')


a=1
b=3
c=2

fprintf('%d * x^2+ %d *x+ %d = 0\n',a,b,c)

[x1,x2]=solve_2grado(a,b,c)
global ndigitos;
ndigitos=4;

a=1
b=-3
c=-10^4

fprintf('%d * x^2+ %d *x+ %d = 0\n',a,b,c)

[x1_rd,x2_rd]=solve_2grado_fls(a,b,c)

rmpath('../biblioteca')